﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Roulette
{
    class Program
    {
        static void Main(string[] args)
        {
            //Unfortunately had to take the song out becuase it say's the file is too big.
            //SoundPlayer players = new SoundPlayer();
            //players.SoundLocation = AppDomain.CurrentDomain.BaseDirectory + "CarelessWhisper.wav";
            //players.Play();
            Program program = new Program();
            program.Run();
        }
        public void Run()
        {
            Board board = new Board();
            GlobalMoney m = new GlobalMoney();
            m.Money(500);
            board.Menu();
        }
    }

}
