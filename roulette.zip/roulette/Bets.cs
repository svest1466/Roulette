﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette
{
    public class Bets
    {

        public static string[] green = new string[] { "0", "00" };
        public static string[] red = new string[] { "1", "3", "5", "7", "9", "12", "14", "16", "18", "19", "21", "23", "25", "27", "30", "32", "34", "36" };
        public static string[] black = new string[] { "2", "4", "6", "8", "10", "11", "13", "15", "17", "20", "22", "24", "26", "28", "29", "31", "33", "35" };

        public static string[] z = new List<string>()
         .Concat(green)
         .Concat(red)
         .Concat(black)
         .ToArray();
        static Random random = new Random();
        int index = random.Next(z.Length);


        Program program = new Program();
        Board board = new Board();

        public void SingleNumber()
        {
            try
            {
                Console.WriteLine("What number do you want to bet on?");
                Console.WriteLine("Choose a number, 1 through 36");
                string x = Console.ReadLine();
                Console.WriteLine("How much money would you like to bet?");
                int y = Convert.ToInt32(Console.ReadLine());


                if (z.Any(i => i == x))
                {
                    Console.WriteLine($"You've selected {x}");
                    if (z[index] == x)
                    {
                        Console.WriteLine("Congratulations! You win!\n");
                        GlobalMoney.PlayerCash += y * 35;
                        Console.ReadLine();
                        Console.Clear();
                    }
                    else
                    {
                        Console.WriteLine($"Oh no! the number was {z[index]} and your guess was {x}!");
                        GlobalMoney.PlayerCash -= y;
                        Console.ReadLine();
                        Console.Clear();
                    }
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();

            }
            board.Menu();

        }
        public void EvensOdds()
        {
            try
            {
                Console.WriteLine($"You have ${GlobalMoney.PlayerCash}");
                Console.WriteLine("Would you like to bet on Evens or Odds?");
                Console.WriteLine("1) Evens 2) Odds");
                int x = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("How much money would you like to bet?");
                int y = Convert.ToInt32(Console.ReadLine());

                var s = z[index];
                int l = int.Parse(s);
                switch (x)
                {

                    case 1:
                        if (l % 2 == 0)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y;
                            Console.ReadLine();
                            
                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;
                            Console.ReadLine();
                            
                        }
                        break;
                    case 2:
                        if (l % 2 != 0)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y;
                            Console.ReadLine();
                            
                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;
                            Console.ReadLine();
                            
                        }
                        break;
                    default:
                        Console.WriteLine("You've entered an invalid response.");
                        Console.ReadLine();
                        break;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();
            }
            Console.Clear();
            board.Menu();
        }
        public void RedsBlack()
        {
            Console.WriteLine("Would you like to bet on Red or Black?");
            Console.WriteLine("1) Red 2) Black");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("How much money would you like to bet?");
            int y = Convert.ToInt32(Console.ReadLine());

            try
            {
                
                string l = Convert.ToString(x);
                var s = z[index];

                switch (x)
                {

                    case 1:
                        if (red.Any(i => i == s))
                        {

                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]} Red!");
                            GlobalMoney.PlayerCash += y;
                            Console.ReadLine();


                        }

                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]} that number is not Red!");
                            GlobalMoney.PlayerCash -= y;
                            Console.ReadLine();


                        }
                        break;
                    case 2:
                        if (black.Any(i => i == s))
                        {


                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]} Black!");
                            GlobalMoney.PlayerCash += y;
                            Console.ReadLine();



                        }

                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]} that number is not Black!");
                            GlobalMoney.PlayerCash -= y;
                            Console.ReadLine();


                        }
                        break;
                    default:
                        Console.WriteLine("You've entered an invalid response.");
                        Console.ReadLine();
                        break;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();

            }
            Console.Clear();
            board.Menu();
        }
        public void LowHigh()
        {

            Console.WriteLine("Would you like to bet on Lows or Highs?");
            Console.WriteLine("1)Lows 1-18 2) Highs 19-36");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("How much money would you like to bet?");
            int y = Convert.ToInt32(Console.ReadLine());

            try
            {
                
                int s = Convert.ToInt32(z[index]);

                switch (x)
                {

                    case 1:
                        if (s <= 18)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y;
                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;
                            Console.ReadLine();


                        }
                        break;
                    case 2:
                        if (s >= 19)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y;
                            Console.ReadLine();



                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;
                            Console.ReadLine();


                        }
                        break;
                    default:
                        Console.WriteLine("You've entered an invalid response.");
                        Console.ReadLine();
                        break;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();

            }
            Console.Clear();
            board.Menu();
        }
        public void Dozen()
        {

            Console.WriteLine("Which dozen would you like to bet on?");
            Console.WriteLine("1) 1-12 2) 13-24 3) 25-36");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("How much money would you like to bet?");
            int y = Convert.ToInt32(Console.ReadLine());

            try
            {

                int s = Convert.ToInt32(z[index]);

                switch (x)
                {

                    case 1:
                        if (s >= 1 && s <= 12)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y * 2;
                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    case 2:
                        if (s >= 13 && s <= 24)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y * 2;

                            Console.ReadLine();



                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    case 3:
                        if (s >= 25 && s <= 36)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y * 2;

                            Console.ReadLine();



                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    default:
                        Console.WriteLine("You've entered an invalid response.");
                        Console.ReadLine();
                        break;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();
            }
            Console.Clear();
            board.Menu();
        }
        public void Columns()
        {
            Console.WriteLine("Which column do you want to bet on?");
            Console.WriteLine("1) First 2) Second 3) Third");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("How much money would you like to bet?");
            int y = Convert.ToInt32(Console.ReadLine());



            int[] column1 = new int[] { 1, 4, 7, 10, 16, 19, 22, 25, 28, 31, 34 };
            int[] column2 = new int[] { 2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35 };
            int[] column3 = new int[] { 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 };

            try
            {
                int s = Convert.ToInt32(z[index]);

                switch (x)
                {
                    case 1:
                        if (column1.Any(i => i == s))
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash = y * 2;

                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;

                    case 2:
                        if (column2.Any(i => i == s))
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash = y * 2;

                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;

                    case 3:
                        if (column3.Any(i => i == s))
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash = y * 2;

                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    default:
                        Console.WriteLine("You've entered an invalid response.");
                        Console.ReadLine();
                        break;

                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();
            }
            Console.Clear();
            board.Menu();
        }
        public void Rows()
        {
            Console.WriteLine("Street (row) do you want to bet on?");
            Console.WriteLine("1) 1        2) 4         3) 7 \n" +
                "4) 10       5) 13        6) 16 \n" +
                "7) 19       8) 22        9) 25 \n" +
                "10) 28     11) 31       12) 34\n");
                int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("How much money would you like to bet?");
            int y = Convert.ToInt32(Console.ReadLine());

            try
            {

                int s = Convert.ToInt32(z[index]);

                if (x == s || x + 1 == s || x + 2 == s)
                {
                    Console.WriteLine($"Congratulations! You've Won! Your numbers were({x},{x + 1},{x + 2})and the winning number was {s}!");
                    GlobalMoney.PlayerCash += y * 11;
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine($"Oh no! You lose again! The number was {s}");
                    GlobalMoney.PlayerCash -= y;
                    Console.ReadLine();
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();
            }
            Console.Clear();
            board.Menu();
        }
        public void SixNumbers()
        {

            Console.WriteLine("Which 6 numbers (double rows) do you want ot bet on?");
            Console.WriteLine("1) 1-6 2) 7-12 3) 13-18 4) 19-24 5) 25-30 6) 31-36");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("How much money would you like to bet?");
            int y = Convert.ToInt32(Console.ReadLine());

            try
            {
                int s = Convert.ToInt32(z[index]);

                switch (x)
                {
                    case 1:
                        if (s >= 1 && s <= 6)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y * 5;

                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    case 2:
                        if (s >= 7 && s <= 12)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y * 5;

                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    case 3:
                        if (s >= 13 && s <= 18)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y * 5;

                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    case 4:
                        if (s >= 19 && s <= 24)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y * 5;

                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    case 5:
                        if (s >= 25 && s <= 30)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y * 5;

                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    case 6:
                        if (s >= 31 && s <= 36)
                        {
                            Console.WriteLine($"Congratulations! You've Won! The number was {z[index]}");
                            GlobalMoney.PlayerCash += y * 5;

                            Console.ReadLine();


                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {z[index]}");
                            GlobalMoney.PlayerCash -= y;

                            Console.ReadLine();


                        }
                        break;
                    default:
                        Console.WriteLine("You've entered an invalid response.");
                        Console.ReadLine();
                        break;


                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();

            }
            Console.Clear();
            board.Menu();
        }
        public void Split()
        {
            int s = Convert.ToInt32(z[index]);

            try
            {
                Console.WriteLine("Pick a number between 1 and 36.");
                int x = Convert.ToInt32(Console.ReadLine());
                if (x > 36 || x < 1)
                {
                    Console.WriteLine("Indvalid entry. Hit enter to continue.");
                    Console.ReadLine();
                    Console.Clear();
                    board.Menu();
                }
                Console.WriteLine("Would you like to split that number with the number next to it, or below it? 1) Adjacent 2) below");
                int f = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("How much money would you like to bet?");
                int y = Convert.ToInt32(Console.ReadLine());
                switch (f)
                {
                    case 1:
                        if (x == 3 || x == 6 || x == 9 || x == 12 || x == 15 || x == 18 || x == 21 || x == 24 || x == 27 || x == 30 || x == 33 || x == 36)
                        {
                            if (x == s || x == s - 1)
                            {
                                Console.WriteLine($"Congratulations! You've Won! Your numbers were({x},{x - 1})and the winning number was {s}!");
                                GlobalMoney.PlayerCash += y * 17;
                                Console.ReadLine();
                            }
                            else
                            {
                                Console.WriteLine($"Oh no! You lose again! The number was {s}");
                                GlobalMoney.PlayerCash -= y;
                                Console.ReadLine();
                            }
                        }
                        if (x == s || x + 1 == s)
                        {
                            Console.WriteLine($"Congratulations! You've Won! Your numbers were({x},{x + 1})and the winning number was {s}!");
                            GlobalMoney.PlayerCash += y * 17;
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {s}");
                            GlobalMoney.PlayerCash -= y;
                            Console.ReadLine();
                        }
                        break;
                    case 2:
                        if (x == 34 || x == 35 || x == 36)
                        {
                            Console.WriteLine("34 , 35 and 36 have no numbers below them. Please hit enter to continue.");
                            Console.ReadLine();
                            Console.Clear();
                            board.Menu();
                        }
                        if (x == s || x + 3 == s)
                        {
                            Console.WriteLine($"Congratulations! You've Won! Your numbers were({x},{x + 3})and the winning number was {s}!");
                            GlobalMoney.PlayerCash += y * 17;
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine($"Oh no! You lose again! The number was {s}");
                            GlobalMoney.PlayerCash -= y;
                            Console.ReadLine();
                        }
                        break;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();
            }
            Console.Clear();
            board.Menu();
        }
        public void Corner()
        {
            int s = Convert.ToInt32(z[index]);
            try
            {
                Console.WriteLine("Pick a number between 1 and 33 you would like to be corners on.");
                int x = Convert.ToInt32(Console.ReadLine());
                if (x > 33 || x < 1)
                {
                    Console.WriteLine("Indvalid entry. Hit enter to continue.");
                    Console.ReadLine();
                    Console.Clear();
                    board.Menu();
                }
                Console.WriteLine("Corners will take the next number in the sequence, and the two below the current numbers.");
                Console.WriteLine("How much money would you like to bet?");
                int y = Convert.ToInt32(Console.ReadLine());

                if (x == 3 || x == 6 || x == 9 || x == 12 || x == 15 || x == 18 || x == 21 || x == 24 || x == 27 || x == 30 || x == 33 || x == 36)
                {
                    if (x == s || x - 1 == s || x + 2 == s || x + 3 == s)
                    {
                        Console.WriteLine($"Congratulations! You've Won! Your numbers were({x},{x - 1}, {x + 2},{x + 3})and the winning number was {s}!");
                        GlobalMoney.PlayerCash += y * 8;
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine($"Oh no! You lose again! Your numbers were({x},{x - 1},{x + 2},{x + 3})and the winning number was {s}!");
                        GlobalMoney.PlayerCash -= y;
                        Console.ReadLine();
                    }
                }

                if (x == s || x + 1 == s || x + 3 == s || x + 4 == s)
                {
                    Console.WriteLine($"Congratulations! You've Won! Your numbers were({x},{x + 1},{x + 3},{x + 4})and the winning number was {s}!");
                    GlobalMoney.PlayerCash += y * 8;
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine($"Oh no! You lose again!Your numbers were({x},{x + 1},{x + 3},{x + 4})and the winning number was {s}!");
                    GlobalMoney.PlayerCash -= y;
                    Console.ReadLine();
                }

            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();
            }
            Console.Clear();
            board.Menu();
        }

    }
}
