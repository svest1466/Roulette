﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette
{
    public class Board
    {
        public void Menu()
        {
            Bets bet = new Bets();


            Console.WriteLine("Welcome to High Roller Roulette!\n");
            if (GlobalMoney.PlayerCash >= 0)
            {
                Console.WriteLine($"You have ${GlobalMoney.PlayerCash}\n");

            }
            else
            {
                Console.WriteLine($"You are now in debt to the casino. We offer a pawn service though. Do you own a car?");
                Console.WriteLine($"You have ${GlobalMoney.PlayerCash}\n");

            }
            Console.WriteLine("Choose how you want to place your bet!\n");



            Console.WriteLine($"Select one of the following to place a bet.\n" +
                "1. Number  2. Evens/odds  3. Reds/Blacks \n" +
                "4. Lows/Highs  5. Dozens  6. Columns \n" +
                "7. Rows  8. PickSix  9. Split  10. Corner  11. Exit");

            try
            {
                int x = Convert.ToInt32(Console.ReadLine());
                switch (x)
                {
                    case 1:
                        bet.SingleNumber();
                        break;
                    case 2:
                        bet.EvensOdds();
                        break;
                    case 3:
                        bet.RedsBlack();
                        break;
                    case 4:
                        bet.LowHigh();
                        break;
                    case 5:
                        bet.Dozen();
                        break;
                    case 6:
                        bet.Columns();
                        break;
                    case 7:
                        bet.Rows();
                        break;
                    case 8:
                        bet.SixNumbers();
                        break;
                    case 9:
                        bet.Split();
                        break;
                    case 10:
                        bet.Corner();
                        break;
                    case 11:
                        Environment.Exit(0);
                        break;
                    default:
                        Program program = new Program();
                        Console.WriteLine("please enter a valid option");
                        program.Run();
                        break;
                }
            }

            catch (FormatException)
            {
                Console.WriteLine("Invalid entry. Please hit enter.");
                Console.ReadLine();
                Console.Clear();
                Program program = new Program();
                program.Run();
            }

        }

        

    }

}
