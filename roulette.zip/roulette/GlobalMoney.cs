﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class GlobalMoney
{
    public static int PlayerCash { get; set; }

    public void Money(int cash)
    {

        PlayerCash = cash;

    }
}
